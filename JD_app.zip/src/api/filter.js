import Vue from 'vue'

Vue.filter('filterMoney', (n) => {
  
})